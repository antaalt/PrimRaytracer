//-------------
// vector.h
//-------------
#if defined(TYPE_H) && !defined(VECTOR_H)
#define VECTOR_H
#include <ostream>
namespace Type {

	namespace {
		constexpr bool isDisplayable(int N, int limit)
		{
			return N > limit;
		}
	}

	template <typename T, int N>
	class Vector {
		static_assert(N > 1 && N < 5, "Vector support only 2, 3, 4 components");
	public:
		Vector();
		Vector(const T a1, const T a2);
		Vector(const T a1, const T a2, const T a3);
		Vector(const T a1, const T a2, const T a3, const T a4);
		Vector(const Vector<T, N> &vec);
		~Vector();

		T &operator[](const int component);
		const T &operator[](const int component) const;

		inline bool operator<(const Vector<T, N> &v) const;
		inline bool operator>(const Vector<T, N> &v) const;

		inline bool operator==(const Vector<T, N> &v) const;
		inline bool operator!=(const Vector<T, N> &v) const;

		template <typename T, int N, typename C>
		friend Vector<T, N> operator*(const Vector<T, N> &vec, const C scalar) const;

		template <typename T, int N, typename C>
		friend Vector<T, N> operator/(const Vector<T, N> &vec, const C scalar) const;

		inline Vector<T, N> operator+(const Vector<T, N> &i) const;
		inline Vector<T, N> operator+(const T &val) const;
		inline Vector<T, N> operator-(const Vector<T, N> &i) const;
		inline Vector<T, N> operator-(const T &val) const;

		inline Vector<T, N> operator+(const Vector<T, N> &i) const;
		inline Vector<T, N> operator+(const T &val) const;
		inline Vector<T, N> operator-(const Vector<T, N> &i) const;
		inline Vector<T, N> operator-(const T &val) const;

		template <typename T, int N>
		friend std::ostream& operator <<(std::ostream& os, const Vector<T, N>& vec) const;

	public:
		float dot(const Vector<T, N> &vec) const;
		float length() const;
		Vector<T, N> reverse() const;

	public:
		union {
			struct {
				T x;
				T y;
				typename std::enable_if<isDisplayable(N, 2), T>::type z;
				typename std::enable_if<isDisplayable(N, 3), T>::type w;
			};
			T data[N];
		};
	};
}
#endif

//-------------
// quaternion.h
//-------------
#if defined(TYPE_H) && !defined(QUATERNION_H)
#define QUATERNION_H
#include "vector.h"
// TODO make it undependant of vector
namespace Type {

	template <typename T>
	class Quaternion : public Vector<T, 4>
	{
		static_assert(std::is_floating_point<T>::value, "Template must be floating point");
	public:
		static Quaternion<T> fromEuler(const T x, const T y, const T z);
		Vector<T, 3> euler();
	};
}
#endif

//-------------
// matrix.h
//-------------
#if defined(TYPE_H) && !defined(MATRIX_H)
#define MATRIX_H

#include <ostream>
namespace Type {

	template <typename T, int N>
	class Matrix {
		static_assert(N > 1 && N < 5, "Matrix support only 2, 3, 4 dimensions");
	public:

#if defined(USE_VECTOR)
		Vector<T, N> &operator[](const int col);
		const Vector<T, N> &operator[](const int col) const;
#else

#endif

		template <typename T, int N>
		friend std::ostream& operator <<(std::ostream& os, const Matrix<T, N>& mat);

	public:
		inline Matrix<T, N> transpose() const;
		inline Matrix<T, N> inverse() const;

		static Matrix<T, N> identity();

	private:
		union {
#if defined(USE_VECTOR)
			Vector<T, N> m_cols[N];
#else
			T m_cols[N][N];
#endif
			T m_data[N * N];
		};
	};
}
#endif // MATRIX_H


//-------------
// config.h
//-------------
#if !defined(CONFIG_H)
#define CONFIG_H

#define USE_VECTOR
#define USE_QUATERNION
#define USE_MATRIX

#if defined(USE_QUATERNION) && !defined(USE_VECTOR)
#define USE_VECTOR
#endif
#if defined(USE_MATRIX) && !defined(USE_VECTOR)
#define USE_VECTOR
#endif

#endif
//-------------
// type.h
//-------------
#if !defined(TYPE_H)
#define TYPE_H
#include "config.h"
#if defined(USE_VECTOR)
#include "vector.h"
typedef Type::Vector<float, 2>			Vector2f;
typedef Type::Vector<float, 3>			Vector3f;
typedef Type::Vector<float, 4>			Vector4f;
typedef Type::Vector<unsigned char, 4>	Vector4u;
#endif
#if defined(USE_MATRIX)
#include "matrix.h"
typedef Type::Matrix<float, 4>			Matrix4f;
typedef Type::Matrix<float, 3>			Matrix3f;
#endif
#if defined(USE_QUATERNION)
#include "quaternion.h"
typedef Type::Quaternion<float>			Quaternionf;
typedef Type::Quaternion<double>		Quaterniond;
#endif

namespace Type {
#if defined(USE_MATRIX) && defined(USE_VECTOR) && defined(USE_QUATERNION)
	template <typename T>
	inline Matrix<T, 4> TRS(Vector<T, 4> &translation, Quaternion<T> &rotation, Vector<T, 4> &scale);
#endif

#if defined(USE_MATRIX) && defined(USE_VECTOR)
	template <typename T>
	void translate(const Matrix<T, 4> &mat, const Vector<T, 3> &vec);
	template <typename T>
	void rotate(const Matrix<T, 4> &mat, const T angle, const Vector<T, 4> &angle);
	template <typename T>
	void scale(const Matrix<T, 4> &mat, const Vector<T, 4> &vec);
#endif
#if defined(USE_MATRIX) && defined(USE_QUATERNION)
	template <typename T>
	void rotate(const Matrix<T, 4> &mat, const Quaternion<T> &quat);

	template <typename T>
	Matrix<T, 4> toMat4(Quaternion<T> &quat);
	template <typename T>
	Quaternion<T> toQuat(Matrix<T, 4> &mat);
#endif


#if defined(USE_VECTOR)

	template <typename T>
	Vector<T, 2> toVec2(Vector<T, 3> &vec);
	template <typename T>
	Vector<T, 2> toVec2(Vector<T, 4> &vec);

	template <typename T>
	Vector<T, 3> toVec3(Vector<T, 2> &vec, T data);
	template <typename T>
	Vector<T, 3> toVec3(Vector<T, 4> &vec);

	template <typename T>
	Vector<T, 4> toVec4(Vector<T, 2> &vec, T data1, T data2);
	template <typename T>
	Vector<T, 4> toVec4(Vector<T, 3> &vec, T data);
#endif

}
#endif