#if !defined(TYPE_H)
#define TYPE_H

#define USE_VECTOR
#define USE_QUATERNION
#define USE_MATRIX

#if defined(USE_QUATERNION) && !defined(USE_VECTOR)
#define USE_VECTOR
#endif
#if defined(USE_MATRIX) && !defined(USE_VECTOR)
#define USE_VECTOR
#endif

#define ASSERT()

#if defined(USE_VECTOR)
#include "vector.h"
typedef Type::Vector<float, 2>			Vector2f;
typedef Type::Vector<float, 3>			Vector3f;
typedef Type::Vector<float, 4>			Vector4f;
typedef Type::Vector<unsigned char, 4>	Vector4u;
typedef Type::Vector<unsigned char, 4>	Color32;
typedef Type::Vector<float, 4>			Color4f;
#endif
#if defined(USE_MATRIX)
#include "matrix.h"
typedef Type::Matrix<float, 2>			Matrix2f;
typedef Type::Matrix<float, 3>			Matrix3f;
typedef Type::Matrix<float, 4>			Matrix4f;
#endif
#if defined(USE_QUATERNION)
#include "quaternion.h"
typedef Type::Quaternion<float>			Quaternionf;
typedef Type::Quaternion<double>		Quaterniond;
#endif

namespace Type {
#if defined(USE_MATRIX) && defined(USE_VECTOR) && defined(USE_QUATERNION)
	template <typename T>
	inline Matrix<T, 4> TRS(Vector<T, 4> &translation, Quaternion<T> &rotation, Vector<T, 4> &scale);
#endif

#if defined(USE_MATRIX) && defined(USE_VECTOR)
	template <typename T>
	void translate(const Matrix<T, 4> &mat, const Vector<T, 3> &vec);
	template <typename T>
	void rotate(const Matrix<T, 4> &mat, const T angle, const Vector<T, 4> &angle);
	template <typename T>
	void scale(const Matrix<T, 4> &mat, const Vector<T, 4> &vec);
#endif
#if defined(USE_MATRIX) && defined(USE_QUATERNION)
	template <typename T>
	void rotate(const Matrix<T, 4> &mat, const Quaternion<T> &quat);

	template <typename T>
	Matrix<T, 4> toMat4(Quaternion<T> &quat);
	template <typename T>
	Quaternion<T> toQuat(Matrix<T, 4> &mat);
#endif


#if defined(USE_VECTOR)


	template <typename T>
	T to(Vector<T, 3> &vec);

	template <typename T>
	Vector<T, 2> toVec2(Vector<T, 3> &vec);
	template <typename T>
	Vector<T, 2> toVec2(Vector<T, 4> &vec);

	template <typename T>
	Vector<T, 3> toVec3(Vector<T, 2> &vec, T data);
	template <typename T>
	Vector<T, 3> toVec3(Vector<T, 4> &vec);

	template <typename T>
	Vector<T, 4> toVec4(Vector<T, 2> &vec, T data1, T data2);
	template <typename T>
	Vector<T, 4> toVec4(Vector<T, 3> &vec, T data);
#endif

}
#endif